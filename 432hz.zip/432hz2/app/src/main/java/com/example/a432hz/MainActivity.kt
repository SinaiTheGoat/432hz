package com.example.a432hz

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
// Check if device is rooted
if (RootTools.isRootAvailable()) {

    // Execute shell command to modify audio service configuration file
    Command command = new Command(0, "su", "tinypitch 8");
    RootTools.getShell(true).add(command);

} else {
    // Display error message to user if device is not rooted
    Toast.makeText(this, "This app requires root access to modify audio settings.", Toast.LENGTH_SHORT).show();
}
